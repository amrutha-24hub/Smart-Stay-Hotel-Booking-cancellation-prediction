
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

file_path = BASE_DIR / "clean_dataset" / "hotel_bookings_clean.csv"
output_folder = BASE_DIR / "outputs"
output_folder.mkdir(exist_ok=True)

df = pd.read_csv(file_path)

print("SMARTSTAY DATA VISUALIZATION STARTED")

# 1. Booking Cancellation Distribution
counts = df["is_canceled"].value_counts().sort_index()

plt.figure(figsize=(7, 5))
plt.bar(["Not Cancelled", "Cancelled"], counts.values)
plt.title("Hotel Booking Cancellation Distribution")
plt.xlabel("Booking Status")
plt.ylabel("Number of Bookings")
plt.tight_layout()
plt.savefig(output_folder / "cancellation_distribution.png")
plt.show()

# 2. Cancellation by Hotel Type
hotel_data = df.groupby("hotel")["is_canceled"].mean() * 100

plt.figure(figsize=(7, 5))
plt.bar(hotel_data.index, hotel_data.values)
plt.title("Cancellation Percentage by Hotel")
plt.xlabel("Hotel Type")
plt.ylabel("Cancellation Percentage")
plt.tight_layout()
plt.savefig(output_folder / "hotel_cancellations.png")
plt.show()

# 3. Lead Time Distribution
plt.figure(figsize=(8, 5))
plt.hist(df["lead_time"], bins=30)
plt.title("Booking Lead Time Distribution")
plt.xlabel("Lead Time (Days)")
plt.ylabel("Number of Bookings")
plt.tight_layout()
plt.savefig(output_folder / "lead_time_distribution.png")
plt.show()

# 4. Cancellation by Deposit Type
deposit_data = df.groupby("deposit_type")["is_canceled"].mean() * 100

plt.figure(figsize=(8, 5))
plt.bar(deposit_data.index, deposit_data.values)
plt.title("Cancellation Percentage by Deposit Type")
plt.xlabel("Deposit Type")
plt.ylabel("Cancellation Percentage")
plt.tight_layout()
plt.savefig(output_folder / "deposit_cancellations.png")
plt.show()

print("All visualizations created successfully!")
print("Charts saved in the outputs folder.")
