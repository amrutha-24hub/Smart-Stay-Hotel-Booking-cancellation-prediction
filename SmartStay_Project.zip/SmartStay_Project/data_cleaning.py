
import pandas as pd
from pathlib import Path

# Project folder
BASE_DIR = Path(__file__).resolve().parent

# File paths
input_file = BASE_DIR / "dataset" / "hotel_bookings.csv"
output_folder = BASE_DIR / "clean_dataset"
output_folder.mkdir(exist_ok=True)

output_file = output_folder / "hotel_bookings_clean.csv"

print("SMARTSTAY DATA CLEANING STARTED")

# Load original dataset
df = pd.read_csv(input_file)

print("Original dataset shape:", df.shape)

# Remove duplicate records
df = df.drop_duplicates()

# Handle missing values
if "children" in df.columns:
    df["children"] = df["children"].fillna(0)

if "country" in df.columns:
    df["country"] = df["country"].fillna("Unknown")

for col in ["agent", "company"]:
    if col in df.columns:
        df[col] = df[col].fillna(0)

# Fill remaining missing text values
for col in df.select_dtypes(include="object").columns:
    df[col] = df[col].fillna("Unknown")

# Fill remaining missing numeric values
for col in df.select_dtypes(include="number").columns:
    if df[col].isnull().any():
        df[col] = df[col].fillna(df[col].median())

# Calculate total stay nights
if {"stays_in_weekend_nights", "stays_in_week_nights"}.issubset(df.columns):
    df["total_nights"] = (
        df["stays_in_weekend_nights"]
        + df["stays_in_week_nights"]
    )

# Save cleaned dataset
df.to_csv(output_file, index=False)

print("Data cleaning completed successfully!")
print("Cleaned dataset shape:", df.shape)
print("Remaining missing values:", df.isnull().sum().sum())
print("Saved file:", output_file)

