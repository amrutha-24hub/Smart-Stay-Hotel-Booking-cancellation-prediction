
import pandas as pd
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

file_path = BASE_DIR / "clean_dataset" / "hotel_bookings_clean.csv"
output_folder = BASE_DIR / "outputs"
output_folder.mkdir(exist_ok=True)

df = pd.read_csv(file_path)

print("\n========== SMARTSTAY DATA ANALYSIS ==========")

total = len(df)
cancelled = (df["is_canceled"] == 1).sum()
successful = (df["is_canceled"] == 0).sum()

print("Total Bookings:", total)
print("Cancelled Bookings:", cancelled)
print("Successful Bookings:", successful)

print("Cancellation Percentage:",
      round(cancelled / total * 100, 2), "%")

print("\nCancellation by Hotel:")
print(df.groupby("hotel")["is_canceled"].mean() * 100)

print("\nCancellation by Customer Type:")
print(df.groupby("customer_type")["is_canceled"].mean() * 100)

print("\nAverage Lead Time:",
      round(df["lead_time"].mean(), 2), "days")

print("\nCancellation by Deposit Type:")
print(df.groupby("deposit_type")["is_canceled"].mean() * 100)

# Save analysis results
summary = pd.DataFrame({
    "Metric": [
        "Total Bookings",
        "Cancelled Bookings",
        "Successful Bookings",
        "Cancellation Percentage",
        "Average Lead Time"
    ],
    "Value": [
        total,
        cancelled,
        successful,
        round(cancelled / total * 100, 2),
        round(df["lead_time"].mean(), 2)
    ]
})

summary.to_csv(output_folder / "booking_analysis.csv", index=False)

print("\nAnalysis completed successfully!")
print("Results saved in outputs folder.")
